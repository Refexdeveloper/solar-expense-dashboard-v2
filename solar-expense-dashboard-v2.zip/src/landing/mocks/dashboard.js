export const statsData = [
    {
        id: 'total-requests',
        icon: 'ri-file-list-3-line',
        title: 'Total Requests',
        value: 1247,
        trend: 12.5,
        trendUp: true,
        gradientFrom: 'primary',
        subtitle: 'All time',
    },
    {
        id: 'pending',
        icon: 'ri-time-line',
        title: 'Pending Approval',
        value: 156,
        trend: 8.3,
        trendUp: true,
        gradientFrom: 'accent',
        subtitle: 'Awaiting action',
    },
    {
        id: 'approved',
        icon: 'ri-check-double-line',
        title: 'Approved',
        value: 984,
        trend: 15.2,
        trendUp: true,
        gradientFrom: 'secondary',
        subtitle: 'This quarter',
    },
    {
        id: 'rejected',
        icon: 'ri-close-circle-line',
        title: 'Rejected',
        value: 107,
        trend: 3.1,
        trendUp: false,
        gradientFrom: 'accent',
        subtitle: 'This quarter',
    },
]

export const tableData = [
    { id: 'REQ-2024-0891', employee: 'Sarah Chen', project: 'Riverside Solar Farm Phase II', category: 'Equipment', amount: 48750, status: 'Approved', date: '2024-06-15' },
    { id: 'REQ-2024-0892', employee: 'Marcus Rivera', project: 'Desert Sun Array', category: 'Labor', amount: 12300, status: 'Pending', date: '2024-06-15' },
    { id: 'REQ-2024-0893', employee: 'Emily Watson', project: 'Green Valley Rooftop', category: 'Materials', amount: 8750, status: 'Approved', date: '2024-06-14' },
    { id: 'REQ-2024-0894', employee: 'James Park', project: 'Riverside Solar Farm Phase II', category: 'Transport', amount: 4200, status: 'Rejected', date: '2024-06-14' },
    { id: 'REQ-2024-0895', employee: 'Lisa Thompson', project: 'Coastal Wind & Solar Hybrid', category: 'Equipment', amount: 92500, status: 'Pending', date: '2024-06-13' },
    { id: 'REQ-2024-0896', employee: 'David Kim', project: 'Metro Industrial Solar', category: 'Permits', amount: 5600, status: 'Approved', date: '2024-06-13' },
    { id: 'REQ-2024-0897', employee: 'Anna Rodriguez', project: 'Desert Sun Array', category: 'Materials', amount: 28300, status: 'Approved', date: '2024-06-12' },
    { id: 'REQ-2024-0898', employee: 'Tom Baker', project: 'Sunrise Community Solar', category: 'Labor', amount: 9100, status: 'Pending', date: '2024-06-12' },
    { id: 'REQ-2024-0899', employee: 'Rachel Green', project: 'Green Valley Rooftop', category: 'Equipment', amount: 34500, status: 'Rejected', date: '2024-06-11' },
    { id: 'REQ-2024-0900', employee: 'Chris Nolan', project: 'Riverside Solar Farm Phase II', category: 'Consulting', amount: 15200, status: 'Approved', date: '2024-06-11' },
    { id: 'REQ-2024-0901', employee: 'Michelle Park', project: 'Coastal Wind & Solar Hybrid', category: 'Transport', amount: 3800, status: 'Approved', date: '2024-06-10' },
    { id: 'REQ-2024-0902', employee: "Kevin O'Brien", project: 'Metro Industrial Solar', category: 'Materials', amount: 19500, status: 'Pending', date: '2024-06-10' },
]

export const expenseCategories = [
    'All Categories',
    'Equipment',
    'Materials',
    'Labor',
    'Transport',
    'Permits',
    'Consulting',
]

export const tableColumns = [
    { key: 'id', label: 'Request No', sortable: true },
    { key: 'employee', label: 'Requestor', sortable: true },
    { key: 'project', label: 'Site', sortable: true },
    { key: 'category', label: 'Category', sortable: true },
    { key: 'amount', label: 'Amount', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
    { key: 'date', label: 'Request Date', sortable: true },
]
