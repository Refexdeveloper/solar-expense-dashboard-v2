function env(name, fallback = '') {
    try {
        const v = typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[name]
        return v != null && String(v).trim() !== '' ? String(v).trim() : fallback
    } catch {
        return fallback
    }
}

/** Kissflow application id for `_application_id=` on process APIs. */
export function resolveAppId(client) {
    if (client?.app?._id) return String(client.app._id).trim()
    if (client?.context?.app?._id) return String(client.context.app._id).trim()
    return env('VITE_KF_APP_ID', 'Solar_Site_Expense_Governance_Syst_A00')
}

export function resolveAdvanceProcessId() {
    return env('VITE_KF_ADVANCE_PROCESS_ID', 'Solar_Advance_Request_YTLA')
}

export function resolveReimbursementProcessId() {
    return env('VITE_KF_REIMBURSEMENT_PROCESS_ID', 'Technician_Reimbursement__YTLM')
}

/** `_application_id` for reimbursement APIs (parent Solar Expense app, not process id). */
export function resolveReimbursementAppId(client) {
    const fromEnv = env('VITE_KF_REIMBURSEMENT_APPLICATION_ID', '')
    if (fromEnv) return fromEnv
    return resolveAppId(client)
}

export function resolveAdvanceReportId() {
    return env('VITE_KF_ADVANCE_REPORT_ID', 'All_Items_A11')
}

export function resolveReimbursementReportId() {
    return env('VITE_KF_REIMBURSEMENT_REPORT_ID', 'All_Items_A12')
}

export function resolvePopupId(kind) {
    if (kind === 'Advance') {
        return env('VITE_KF_POPUP_ADVANCE', 'Popup_6EVNyeI5ca')
    }
    if (kind === 'Reimbursement') {
        return env('VITE_KF_POPUP_REIMBURSEMENT', 'Popup_JOzzdtsOik')
    }
    return ''
}

/** Normalize kf.api() payloads (`{ data }` vs `{ Data }` vs raw). */
export function unwrapKfApiResponse(resp) {
    if (resp == null) return resp
    if (Array.isArray(resp)) return resp
    if (typeof resp !== 'object') return resp
    if (resp.data !== undefined && resp.data !== null) return resp.data
    if (resp.Data !== undefined && resp.Data !== null) return resp.Data
    return resp
}

export function extractListPayload(resp) {
    const body = unwrapKfApiResponse(resp)
    if (Array.isArray(body)) return body
    if (Array.isArray(body?.Data)) return body.Data
    if (Array.isArray(body?.data)) return body.data
    if (Array.isArray(body?.Item)) return body.Item
    if (Array.isArray(body?.items)) return body.items
    return []
}
