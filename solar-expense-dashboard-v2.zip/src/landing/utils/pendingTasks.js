import {
    extractListPayload,
    resolveAdvanceProcessId,
    resolveAdvanceReportId,
    resolveAppId,
    resolveReimbursementAppId,
    resolveReimbursementProcessId,
    resolveReimbursementReportId,
} from './kfEnv.js'

/** @deprecated Use resolveAppId(client) — kept for reference / local tooling. */
export const APP_ID = 'Solar_Site_Expense_Governance_Syst_A00'

export const PROCESS_IDS = {
    advance: 'Solar_Advance_Request_YTLA',
    reimbursement: 'Technician_Reimbursement__YTLM',
}

export const REQUEST_TYPE_OPTIONS = [
    { id: 'advance', label: 'Advance', icon: 'ri-sun-line' },
    { id: 'reimbursement', label: 'Reimbursement', icon: 'ri-file-list-3-line' },
]

/** All Items report + column ids for Advance (Solar Advance Request). */
export const ADVANCE_REPORT = {
    reportId: 'All_Items_A11',
    fields: {
        requestNo: 'Column_JNgPoZGZis',
        requestAmount: 'Column_XFU4vgscWp',
        site: 'Column_iJWnwoiamJ',
        category: 'Column_Xjls1FEtUh',
        requestDate: 'Column_Mm4IX6IoV7',
        status: 'Column_iO9N16ppIo',
        createdBy: 'Column_3hkVma1Tpv',
        requestorEmail: 'Column_e_6rPkprzZ',
        createdAt: 'Column_IUYBvxeIca',
        currentStep: 'Column_vvX95q_obP',
    },
    rawFieldIds: {
        requestNo: 'Request_No',
        requestAmount: 'requested_amount_YTLF',
        site: 'Side_ID',
        category: 'Budget_Category',
        requestDate: 'request_date_YTLI',
        status: '_status',
        createdBy: '_created_by',
        createdAt: '_created_at',
        currentStep: '_current_step',
        requestorEmail: 'Requested_Email',
    },
}

export const ADVANCE_TABLE_COLUMNS = [
    { key: 'id', label: 'Request No', sortable: true },
    { key: 'employee', label: 'Requestor', sortable: true },
    { key: 'project', label: 'Site', sortable: true },
    { key: 'category', label: 'Category', sortable: true },
    { key: 'amount', label: 'Amount', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
    { key: 'date', label: 'Request Date', sortable: true },
]

/** All Items report + column ids for Reimbursement (All_Items_A12). */
export const REIMBURSEMENT_REPORT = {
    reportId: 'All_Items_A12',
    fields: {
        claimNo: 'Column_kwAjGf7kER',
        requestAmount: 'Column_Y6BPVVxBJD',
        site: 'Column_EhiVPHSazx',
        expenseType: 'Column_Aws67JJR8Q',
        serviceCategory: 'Column_rrn9ndDObK',
        claimMonth: 'Column_UgI9rS3ORp',
        claimMonthFallback: 'Column_9X5YHAO70s',
        status: 'Column_lstKxONrIt',
        createdBy: 'Column_-MImniM8u0',
        requestorEmail: 'Column_eoqqjEe612',
        createdAt: 'Column_cCeKrTSpJL',
        currentStep: 'Column_BM-zCc0rWo',
    },
    rawFieldIds: {
        claimNo: 'Claim_No',
        requestAmount: 'Request_Amount',
        site: 'Side_ID',
        expenseType: 'Expense_Type',
        serviceCategory: 'Service_Category',
        claimMonth: 'claim_month_YTLN',
        status: '_status',
        createdBy: '_created_by',
        createdAt: '_created_at',
        currentStep: '_current_step',
        requestorEmail: 'Requested_Email',
    },
}

export const REIMBURSEMENT_TABLE_COLUMNS = [
    { key: 'id', label: 'Claim No', sortable: true },
    { key: 'employee', label: 'Requestor', sortable: true },
    { key: 'project', label: 'Site', sortable: true },
    { key: 'category', label: 'Expense Type', sortable: true },
    { key: 'amount', label: 'Amount', sortable: true },
    { key: 'status', label: 'Status', sortable: true },
    { key: 'date', label: 'Claim Month', sortable: true },
]

const TABLE_COLUMNS_BY_TYPE = {
    advance: ADVANCE_TABLE_COLUMNS,
    reimbursement: REIMBURSEMENT_TABLE_COLUMNS,
}

const PAGE_SIZE = 100
const MAX_PAGES = 20

/** Build instance → activity map from PWA myitems rows (popup fallback). */
function buildInstanceActivityMapFromRows(rows) {
    const map = {}
    if (!Array.isArray(rows)) return map
    for (const item of rows) {
        const instanceId = item?._id ? String(item._id).trim() : ''
        const activityId = item?._activity_instance_id ? String(item._activity_instance_id).trim() : ''
        if (instanceId && activityId && !map[instanceId]) {
            map[instanceId] = activityId
        }
    }
    return map
}

/** Site Incharge — PWA myitems (Advance + Reimbursement). */
async function fetchPwaMyItemsRaw(accountId, processId, appId, apiGet) {
    if (!accountId || !processId || typeof apiGet !== 'function') return []
    const allRows = []
    for (let page = 1; page <= MAX_PAGES; page++) {
        const url =
            `/process/2/${accountId}/pwa/${processId}/myitems` +
            `?_application_id=${encodeURIComponent(appId)}&page_number=${page}&page_size=${PAGE_SIZE}`
        const pageRows = extractListPayload(await apiGet(url))
        if (!pageRows.length) break
        allRows.push(...pageRows)
        if (pageRows.length < PAGE_SIZE) break
    }
    return allRows
}

/** My Tasks — PWA pending API (Advance + Reimbursement). */
async function fetchPwaPendingRaw(accountId, processId, appId, apiGet) {
    if (!accountId || !processId || typeof apiGet !== 'function') return []
    const allRows = []
    for (let page = 1; page <= MAX_PAGES; page++) {
        const url =
            `/process/2/${accountId}/pwa/${processId}/pending` +
            `?_application_id=${encodeURIComponent(appId)}&page_number=${page}&page_size=${PAGE_SIZE}`
        const pageRows = extractListPayload(await apiGet(url))
        if (!pageRows.length) break
        allRows.push(...pageRows)
        if (pageRows.length < PAGE_SIZE) break
    }
    return allRows
}

const KF_LIST_PAGE_SIZE = 50

async function fetchParticipatedActivities(accountId, processId, appId, apiGet) {
    const url = `/process/2/${accountId}/${processId}/participated/activity/count?_application_id=${encodeURIComponent(appId)}`
    const body = extractListPayload(await apiGet(url))
    return Array.isArray(body) ? body : []
}

async function fetchParticipatedForActivity(accountId, processId, appId, activityId, apiGet) {
    const allRows = []
    for (let page = 1; page <= MAX_PAGES; page++) {
        const url =
            `/process/2/${accountId}/${processId}/participated/activity/${encodeURIComponent(String(activityId))}` +
            `?apply_preference=true&page_number=${page}&page_size=${KF_LIST_PAGE_SIZE}&skip_aggregation=true&_application_id=${encodeURIComponent(appId)}`
        const pageRows = extractListPayload(await apiGet(url))
        if (!pageRows.length) break
        allRows.push(...pageRows)
        if (pageRows.length < KF_LIST_PAGE_SIZE) break
    }
    return allRows
}

async function fetchAllParticipatedItems(accountId, processId, appId, apiGet) {
    const activities = await fetchParticipatedActivities(accountId, processId, appId, apiGet)
    const merge = []
    for (const activity of activities) {
        const activityId = activity?._id
        if (!activityId) continue
        const rows = await fetchParticipatedForActivity(accountId, processId, appId, activityId, apiGet)
        merge.push(...rows)
    }
    return merge
}

async function fetchRawReportRows(accountId, processId, reportId, appId, apiGet) {
    const allRows = []
    for (let page = 1; page <= MAX_PAGES; page++) {
        const url = `/process-report/2/${accountId}/${processId}/${reportId}?_application_id=${encodeURIComponent(appId)}&page_number=${page}&page_size=${PAGE_SIZE}`
        const resp = await apiGet(url)
        const pageRows = extractListPayload(resp)
        if (!pageRows.length) break
        allRows.push(...pageRows)
        if (pageRows.length < PAGE_SIZE) break
    }
    return allRows
}

function buildReportRowMap(reportRows) {
    const map = {}
    for (const row of reportRows) {
        const id = String(row?._id ?? '').trim()
        if (id) map[id] = row
    }
    return map
}

function readRowField(row, reportConfig, key) {
    const columnId = reportConfig?.fields?.[key]
    if (columnId && row?.[columnId] !== undefined && row?.[columnId] !== null && row?.[columnId] !== '') {
        return row[columnId]
    }
    const rawFieldId = reportConfig?.rawFieldIds?.[key]
    if (rawFieldId && row?.[rawFieldId] !== undefined && row?.[rawFieldId] !== null && row?.[rawFieldId] !== '') {
        return row[rawFieldId]
    }
    return undefined
}

function cellToText(cell) {
    if (cell == null || cell === '') return ''
    if (typeof cell === 'string' || typeof cell === 'number' || typeof cell === 'boolean') return String(cell)
    if (typeof cell === 'object') {
        return String(cell.Name ?? cell.name ?? cell.Value ?? cell.value ?? cell.Email ?? cell.email ?? '').trim()
    }
    return String(cell).trim()
}

function toNumber(val) {
    const n = Number(String(val ?? '').replace(/[^\d.-]/g, ''))
    return Number.isFinite(n) ? n : 0
}

function siteNameFromRef(val) {
    if (val == null || val === '') return ''
    if (typeof val === 'object') {
        return String(val.site_name_fqiW ?? val.Name ?? val.name ?? '').trim()
    }
    return String(val).trim()
}

function normalizeStatus(raw) {
    const s = String(raw ?? '').trim()
    if (!s) return 'Pending'
    if (s === 'InProgress') return 'Pending'
    if (s === 'Completed') return 'Approved'
    if (s === 'Rejected') return 'Rejected'
    if (/pending/i.test(s)) return 'Pending'
    if (/approv|complete/i.test(s)) return 'Approved'
    if (/reject/i.test(s)) return 'Rejected'
    return s
}

function formatDateValue(raw) {
    const text = cellToText(raw)
    if (!text) return ''
    const d = new Date(text)
    if (Number.isNaN(d.getTime())) return text
    return d.toISOString().slice(0, 10)
}

function rowBelongsToUser(row, reportConfig, userEmail, userId) {
    const emailNeedle = String(userEmail || '').trim().toLowerCase()
    const userNeedle = String(userId || '').trim()
    const fields = reportConfig?.fields || {}
    const rawFieldIds = reportConfig?.rawFieldIds || {}

    const requestorEmail = cellToText(
        readRowField(row, reportConfig, 'requestorEmail') ??
            row?.Requestor_Email ??
            row?.requestor_email ??
            row?.Email_Id ??
            row?.Email
    )
        .trim()
        .toLowerCase()
    if (emailNeedle && requestorEmail && requestorEmail === emailNeedle) return true

    const createdBy =
        row?.[fields.createdBy] ??
        row?.[rawFieldIds.createdBy] ??
        row?._created_by
    const createdById = typeof createdBy === 'object' ? String(createdBy?._id ?? '').trim() : ''
    const createdByEmail = typeof createdBy === 'object'
        ? String(createdBy?.Email ?? createdBy?.email ?? '').trim().toLowerCase()
        : ''

    if (userNeedle && createdById && createdById === userNeedle) return true
    if (emailNeedle && createdByEmail && createdByEmail === emailNeedle) return true

    return !emailNeedle && !userNeedle
}

function categoryToText(expenseType, serviceCategory) {
    const expense = cellToText(expenseType)
    if (expense) return expense
    if (Array.isArray(serviceCategory)) {
        const joined = serviceCategory.map((item) => cellToText(item)).filter(Boolean).join(', ')
        if (joined) return joined
    }
    return cellToText(serviceCategory)
}

function resolveActivityId(pwaRow, reportRow, instanceActivityMap) {
    const instanceId = String(pwaRow?._id ?? reportRow?._id ?? '').trim()
    const mapActivityId = instanceId && instanceActivityMap ? String(instanceActivityMap[instanceId] ?? '').trim() : ''
    return String(
        pwaRow?._activity_instance_id ??
            pwaRow?._context_activity_instance_id ??
            pwaRow?.ActivityID ??
            pwaRow?.activity_id ??
            reportRow?._activity_instance_id ??
            reportRow?._context_activity_instance_id ??
            mapActivityId ??
            ''
    ).trim()
}

function mapDisplayRow(dataRow, reportConfig, idFieldKey, categoryResolver, instanceId, activityId) {
    const displayId = cellToText(readRowField(dataRow, reportConfig, idFieldKey))

    return {
        id: displayId || instanceId || '—',
        employee: cellToText(readRowField(dataRow, reportConfig, 'createdBy')) || '—',
        project: siteNameFromRef(readRowField(dataRow, reportConfig, 'site')) || cellToText(readRowField(dataRow, reportConfig, 'site')) || '—',
        category: categoryResolver(dataRow, reportConfig) || '—',
        amount: toNumber(readRowField(dataRow, reportConfig, 'requestAmount')),
        status: normalizeStatus(readRowField(dataRow, reportConfig, 'status')),
        date:
            formatDateValue(
                readRowField(dataRow, reportConfig, 'requestDate') ??
                    readRowField(dataRow, reportConfig, 'claimMonth') ??
                    readRowField(dataRow, reportConfig, 'claimMonthFallback') ??
                    readRowField(dataRow, reportConfig, 'createdAt') ??
                    dataRow?._created_at
            ) || '—',
        instanceId,
        activityId,
        currentStep: cellToText(readRowField(dataRow, reportConfig, 'currentStep')),
    }
}

function mapReportRow(row, reportConfig, userEmail, userId, idFieldKey, categoryResolver, instanceActivityMap) {
    if (!row || typeof row !== 'object') return null
    if (!rowBelongsToUser(row, reportConfig, userEmail, userId)) return null

    const instanceId = String(row._id ?? '').trim()
    const activityId = resolveActivityId(null, row, instanceActivityMap)

    return mapDisplayRow(row, reportConfig, idFieldKey, categoryResolver, instanceId, activityId)
}

function mapEnrichedPwaRow(pwaRow, reportRow, reportConfig, idFieldKey, categoryResolver, instanceActivityMap) {
    if (!pwaRow || typeof pwaRow !== 'object' || !reportRow) return null
    const dataRow = { ...pwaRow, ...reportRow }
    const instanceId = String(pwaRow._id ?? reportRow._id ?? '').trim()
    if (!instanceId) return null
    const activityId = resolveActivityId(pwaRow, reportRow, instanceActivityMap)

    return mapDisplayRow(dataRow, reportConfig, idFieldKey, categoryResolver, instanceId, activityId)
}

function mapAdvanceRow(row, reportConfig, userEmail, userId, instanceActivityMap) {
    return mapReportRow(
        row,
        reportConfig,
        userEmail,
        userId,
        'requestNo',
        (r, cfg) => cellToText(readRowField(r, cfg, 'category')),
        instanceActivityMap
    )
}

function mapReimbursementRow(row, reportConfig, userEmail, userId, instanceActivityMap) {
    return mapReportRow(
        row,
        reportConfig,
        userEmail,
        userId,
        'claimNo',
        (r, cfg) => categoryToText(readRowField(r, cfg, 'expenseType'), readRowField(r, cfg, 'serviceCategory')),
        instanceActivityMap
    )
}

function mapAdvancePwaRow(pwaRow, reportRow, reportConfig, instanceActivityMap) {
    return mapEnrichedPwaRow(
        pwaRow,
        reportRow,
        reportConfig,
        'requestNo',
        (r, cfg) => cellToText(readRowField(r, cfg, 'category')),
        instanceActivityMap
    )
}

function mapReimbursementPwaRow(pwaRow, reportRow, reportConfig, instanceActivityMap) {
    return mapEnrichedPwaRow(
        pwaRow,
        reportRow,
        reportConfig,
        'claimNo',
        (r, cfg) => categoryToText(readRowField(r, cfg, 'expenseType'), readRowField(r, cfg, 'serviceCategory')),
        instanceActivityMap
    )
}

export function buildStatsFromRows(rows, requestType) {
    const total = rows.length
    const pending = rows.filter((r) => r.status === 'Pending').length
    const approved = rows.filter((r) => r.status === 'Approved').length
    const rejected = rows.filter((r) => r.status === 'Rejected').length
    const label = requestType === 'advance' ? 'Advance' : 'Reimbursement'

    return [
        {
            id: 'total-requests',
            icon: 'ri-file-list-3-line',
            title: 'Total Requests',
            value: total,
            trend: 0,
            trendUp: true,
            gradientFrom: 'primary',
            subtitle: `My ${label} requests`,
        },
        {
            id: 'pending',
            icon: 'ri-sun-line',
            title: 'Pending',
            value: pending,
            trend: 0,
            trendUp: true,
            gradientFrom: 'warning',
            subtitle: 'In progress',
        },
        {
            id: 'approved',
            icon: 'ri-checkbox-circle-line',
            title: 'Approved',
            value: approved,
            trend: 0,
            trendUp: true,
            gradientFrom: 'success',
            subtitle: 'Completed',
        },
        {
            id: 'rejected',
            icon: 'ri-close-circle-line',
            title: 'Rejected',
            value: rejected,
            trend: 0,
            trendUp: false,
            gradientFrom: 'danger',
            subtitle: 'Declined',
        },
    ]
}

function resolveProcessAppId(client, requestType, appId) {
    if (requestType === 'reimbursement') return resolveReimbursementAppId(client)
    return appId || resolveAppId(client) || APP_ID
}

/** Count participated API rows for overview (approved); prefer report-enriched match when available. */
function countParticipatedForOverview(participatedRawRows, reportById, reportConfig, mapPwaRow) {
    const seen = new Set()
    let count = 0
    for (const item of participatedRawRows) {
        const instanceId = String(item?._id ?? '').trim()
        if (!instanceId || seen.has(instanceId)) continue
        seen.add(instanceId)

        const reportRow = reportById[instanceId] || null
        if (reportRow && mapPwaRow(item, reportRow, reportConfig, {})) {
            count += 1
            continue
        }
        count += 1
    }
    return count
}

/** Non–Site Incharge overview: pending from table (My Tasks), approved from participated. */
function buildNonInchargeStatsWithParticipated(
    pendingRows,
    participatedRawRows,
    reportConfig,
    mapPwaRow,
    reportById,
    requestType
) {
    const pendingCount = pendingRows.length
    const rejectedCount = pendingRows.filter((row) => row.status === 'Rejected').length
    const participatedCount = countParticipatedForOverview(
        participatedRawRows,
        reportById,
        reportConfig,
        mapPwaRow
    )

    const stats = buildStatsFromRows([], requestType)
    return stats.map((card) => {
        if (card.id === 'total-requests') return { ...card, value: pendingCount + participatedCount }
        if (card.id === 'pending') return { ...card, value: pendingCount }
        if (card.id === 'approved') return { ...card, value: participatedCount, subtitle: 'Participated' }
        if (card.id === 'rejected') return { ...card, value: rejectedCount }
        return card
    })
}

function mapPwaRowsEnriched(pwaRows, reportById, reportConfig, mapPwaRow, instanceActivityMap, requireReportMatch = false) {
    const rows = []
    for (const pwaItem of pwaRows) {
        const instanceId = String(pwaItem?._id ?? '').trim()
        const reportRow = instanceId ? reportById[instanceId] : null
        if (requireReportMatch && !reportRow) continue
        const mapped = mapPwaRow(pwaItem, reportRow, reportConfig, instanceActivityMap)
        if (mapped) rows.push(mapped)
    }
    return rows
}

function getRequestConfig(client, requestType) {
    if (requestType === 'advance') {
        return {
            processId: resolveAdvanceProcessId(),
            report: {
                ...ADVANCE_REPORT,
                reportId: resolveAdvanceReportId(),
            },
            mapReport: mapAdvanceRow,
            mapPwa: mapAdvancePwaRow,
        }
    }
    if (requestType === 'reimbursement') {
        return {
            processId: resolveReimbursementProcessId(),
            report: {
                ...REIMBURSEMENT_REPORT,
                reportId: resolveReimbursementReportId(),
            },
            mapReport: mapReimbursementRow,
            mapPwa: mapReimbursementPwaRow,
        }
    }
    return null
}

export async function fetchDashboardData(
    accountId,
    requestType,
    apiGet,
    userEmail,
    userId,
    isSiteIncharge = false,
    client = null,
    appId = ''
) {
    const columns = TABLE_COLUMNS_BY_TYPE[requestType] ?? ADVANCE_TABLE_COLUMNS

    if (!accountId || typeof apiGet !== 'function') {
        return { rows: [], stats: buildStatsFromRows([], requestType), columns }
    }

    const cfg = getRequestConfig(client, requestType)
    if (!cfg) {
        return { rows: [], stats: buildStatsFromRows([], requestType), columns }
    }

    const { processId, report: reportConfig, mapPwa } = cfg
    const resolvedAppId = resolveProcessAppId(client, requestType, appId)

    const rawReportRows = await fetchRawReportRows(accountId, processId, reportConfig.reportId, resolvedAppId, apiGet)
    const reportById = buildReportRowMap(rawReportRows)

    let pwaRows = []
    let instanceActivityMap = {}
    if (isSiteIncharge) {
        pwaRows = await fetchPwaMyItemsRaw(accountId, processId, resolvedAppId, apiGet)
        instanceActivityMap = buildInstanceActivityMapFromRows(pwaRows)
    } else {
        pwaRows = await fetchPwaPendingRaw(accountId, processId, resolvedAppId, apiGet)
    }

    const tableRows = mapPwaRowsEnriched(pwaRows, reportById, reportConfig, mapPwa, instanceActivityMap, true)

    let stats
    if (isSiteIncharge) {
        stats = buildStatsFromRows(tableRows, requestType)
    } else {
        const participatedRows = await fetchAllParticipatedItems(accountId, processId, resolvedAppId, apiGet)
        stats = buildNonInchargeStatsWithParticipated(
            tableRows,
            participatedRows,
            reportConfig,
            mapPwa,
            reportById,
            requestType
        )
    }

    if (import.meta.env?.DEV) {
        console.info('[solar-expense-dashboard] fetch summary', {
            requestType,
            accountId,
            appId: resolvedAppId,
            processId,
            reportId: reportConfig.reportId,
            isSiteIncharge,
            dataSource: isSiteIncharge ? 'pwa-myitems' : 'pwa-pending',
            rawReportCount: rawReportRows.length,
            tableRowCount: tableRows.length,
            userEmail,
        })
    }

    return { rows: tableRows, stats, columns }
}
