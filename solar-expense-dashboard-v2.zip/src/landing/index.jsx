import { useContext, useEffect, useMemo, useRef, useState } from 'react'
import { KissflowSDKContext, kf } from '../sdk/index.js'
import WelcomeHeader from './components/WelcomeHeader.jsx'
import StatsCards from './components/StatsCards.jsx'
import DataTable from './components/DataTable.jsx'
import { fetchDashboardData } from './utils/pendingTasks.js'
import { resolveAppId, resolvePopupId, unwrapKfApiResponse } from './utils/kfEnv.js'
import {
    resolveCurrentRoleName,
    resolveRoleNameFromProfile,
    shouldShowCreateFab,
} from './utils/kfRole.js'

function getClient() {
    return typeof window !== 'undefined' && window.kf ? window.kf : kf
}

function openPopup(label, params = {}) {
    const client = getClient()
    const popupId = resolvePopupId(label)
    if (!popupId) return
    if (!client?.app?.page?.openPopup) {
        console.warn('Kissflow SDK not ready')
        return
    }
    try {
        client.app.page.openPopup(popupId, params)
    } catch (e) {
        console.error('openPopup failed', e)
        client.client?.showInfo?.(`Unable to open the ${label} form.`)
    }
}

function popupLabelForRequestType(requestType) {
    return requestType === 'reimbursement' ? 'Reimbursement' : 'Advance'
}

function forceShowCreateFab() {
    try {
        return String(import.meta.env?.VITE_SHOW_CREATE_FAB || '').trim().toLowerCase() === 'true'
    } catch {
        return false
    }
}

export function DefaultLandingComponent() {
    const { kf: kfFromContext, sdkReady } = useContext(KissflowSDKContext)
    const [requestType, setRequestType] = useState('advance')
    const [stats, setStats] = useState([])
    const [tableRows, setTableRows] = useState([])
    const [tableColumns, setTableColumns] = useState([])
    const [dataError, setDataError] = useState('')
    const [loading, setLoading] = useState(true)
    const fetchSeqRef = useRef(0)

    const client = kfFromContext ?? getClient()
    const userName = (client && client.user && client.user.Name) || ''
    const accountId = client?.account?._id || client?.context?.account?._id
    const userId = String(client?.user?._id || client?.context?.user?._id || '').trim()
    const userEmail = String(client?.user?.Email || client?.user?.email || client?.context?.user?.Email || '')
        .trim()
        .toLowerCase()
    const appId = useMemo(() => resolveAppId(client), [client, sdkReady])
    const [userProfile, setUserProfile] = useState(null)
    const [appRoleName, setAppRoleName] = useState('')
    const [roleName, setRoleName] = useState(() => resolveCurrentRoleName(client))

    const isSiteIncharge = useMemo(
        () =>
            shouldShowCreateFab({
                client,
                profile: userProfile,
                extraRoleNames: [roleName, appRoleName],
                forceShow: forceShowCreateFab(),
            }),
        [client, userProfile, roleName, appRoleName]
    )
    const showFabAction = isSiteIncharge

    const [resolvedCompany, setResolvedCompany] = useState(() =>
        String(client?.user?.Company || client?.context?.user?.Company || '').trim()
    )
    const companyDisplayName = resolvedCompany.trim() || 'Refex Group'

    const expenseCategories = useMemo(() => {
        const cats = [
            ...new Set(
                tableRows
                    .map((r) => String(r?.category || '').trim())
                    .filter(Boolean)
            ),
        ]
        return ['All Categories', ...cats]
    }, [tableRows])

    useEffect(() => {
        const fromSdk = resolveCurrentRoleName(client)
        if (fromSdk) setRoleName(fromSdk)
    }, [client, sdkReady, kfFromContext])

    useEffect(() => {
        if (!sdkReady || !client?.app?.getVariable) return
        let cancelled = false
        ;(async () => {
            try {
                const variableRole = await client.app.getVariable('user_role_name')
                const resolved = String(variableRole || '').trim()
                if (!cancelled && resolved) setAppRoleName(resolved)
            } catch {
                // optional — same pattern as LeadsManagementPage
            }
        })()
        return () => {
            cancelled = true
        }
    }, [sdkReady, client, userProfile, roleName])

    useEffect(() => {
        if (!sdkReady || !accountId || !userId || typeof client?.api !== 'function') return
        let cancelled = false
        ;(async () => {
            try {
                const appQuery = appId ? `?_application_id=${encodeURIComponent(appId)}` : ''
                const url = `/user/2/${accountId}/${userId}${appQuery}`
                const resp = await client.api(url, {
                    method: 'GET',
                    headers: { Accept: 'application/json' },
                })
                const profile = unwrapKfApiResponse(resp)
                const co = String(profile?.Company ?? '').trim()
                const role = resolveRoleNameFromProfile(profile, client)
                if (!cancelled && profile) setUserProfile(profile)
                if (!cancelled && co) setResolvedCompany(co)
                if (!cancelled && role) setRoleName(role)
            } catch (e) {
                console.warn('[solar-expense-dashboard] User profile fetch failed', e)
            }
        })()
        return () => {
            cancelled = true
        }
    }, [sdkReady, accountId, userId, client, appId])

    const loadDashboard = async () => {
        const seq = ++fetchSeqRef.current
        const activeClient = getClient()
        setLoading(true)
        setDataError('')

        const apiGet = async (url) => {
            try {
                const resp = await activeClient.api(url, {
                    method: 'GET',
                    headers: { Accept: 'application/json' },
                })
                return unwrapKfApiResponse(resp)
            } catch (e) {
                console.error('[solar-expense-dashboard] API failed', url, e)
                throw e
            }
        }

        try {
            if (!sdkReady || !accountId || typeof activeClient?.api !== 'function') {
                if (seq === fetchSeqRef.current) {
                    setStats([])
                    setTableRows([])
                }
                return
            }

            const { stats: nextStats, rows: nextRows, columns: nextColumns } = await fetchDashboardData(
                accountId,
                requestType,
                apiGet,
                userEmail,
                userId,
                isSiteIncharge,
                activeClient,
                appId
            )
            if (seq !== fetchSeqRef.current) return
            setStats(nextStats)
            setTableRows(nextRows)
            setTableColumns(nextColumns)
        } catch (e) {
            if (seq !== fetchSeqRef.current) return
            console.error('Dashboard fetch failed', e)
            setDataError('Unable to load my tasks.')
            setStats([])
            setTableRows([])
        } finally {
            if (seq === fetchSeqRef.current) setLoading(false)
        }
    }

    useEffect(() => {
        void loadDashboard()
    }, [requestType, accountId, userEmail, userId, isSiteIncharge, roleName, sdkReady, appId])

    const handleFabAction = (label) => {
        if (!showFabAction) return
        if (resolvePopupId(label)) {
            openPopup(label)
            return
        }
        client?.client?.showInfo?.(`${label} — coming soon.`)
    }

    const handleRowClick = (row) => {
        const label = popupLabelForRequestType(requestType)
        const instanceId = String(row?.instanceId || '').trim()
        const activityId = String(row?.activityId || '').trim()
        if (!instanceId) {
            client?.client?.showInfo?.('Unable to open this record: missing instance id.')
            return
        }
        if (!activityId) {
            client?.client?.showInfo?.('Unable to open this record: missing activity id.')
            return
        }

        openPopup(label, {
            instance_id: instanceId,
            activity_id: activityId,
            InstanceId: instanceId,
            ActivityID: activityId,
            ActivityId: activityId,
            activityId,
            InstanceID: instanceId,
        })
    }

    return (
        <div className="dashboard-page">
            <div className="max-w-[1400px] mx-auto px-4 md:px-6 lg:px-8 py-6 md:py-8 space-y-6 md:space-y-8">
                <WelcomeHeader
                    userName={userName}
                    companyName={companyDisplayName}
                    onFabAction={handleFabAction}
                    showFabAction={showFabAction}
                />

                {dataError && (
                    <div className="text-sm p-3.5 rounded-xl border border-danger-100 bg-danger-50 text-danger-700 font-medium">
                        {dataError}
                    </div>
                )}

                <StatsCards
                    stats={stats}
                    loading={loading}
                    requestType={requestType}
                    onRequestTypeChange={setRequestType}
                />

                <DataTable
                    rows={tableRows}
                    columns={tableColumns}
                    categories={expenseCategories}
                    loading={loading}
                    requestType={requestType}
                    onRowClick={handleRowClick}
                />

                <footer className="text-center py-6">
                    <p className="text-sm text-foreground-400">
                        &copy; {new Date().getFullYear()} {companyDisplayName}. All rights reserved.
                    </p>
                </footer>
            </div>
        </div>
    )
}
