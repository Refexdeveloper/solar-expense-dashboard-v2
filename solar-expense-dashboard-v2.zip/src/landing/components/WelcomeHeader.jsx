import FloatingActionButton from './FloatingActionButton.jsx'
import { SolarAvatarIcon } from './SolarIllustrations.jsx'

export default function WelcomeHeader({ userName, companyName, onFabAction, showFabAction }) {
    const displayName = userName?.trim() || 'User'

    return (
        <div className="dashboard-header relative w-full px-5 py-5 sm:px-7 sm:py-6">
            <div className="dashboard-header-inner relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div className="flex items-center gap-4 min-w-0 flex-1">
                    <div className="welcome-avatar-badge shrink-0">
                        <SolarAvatarIcon className="w-14 h-14 sm:w-[4.25rem] sm:h-[4.25rem]" />
                    </div>
                    <div className="min-w-0">
                        <h1 className="welcome-title text-xl sm:text-[1.65rem] font-heading font-bold leading-tight">
                            Welcome, {displayName}{' '}
                            <span role="img" aria-label="sun">
                                ☀️
                            </span>
                        </h1>
                        <p className="welcome-subtitle text-sm sm:text-base mt-1 font-body truncate">{companyName}</p>
                    </div>
                </div>

                {showFabAction ? (
                    <div className="header-fab-zone self-start sm:self-center ml-auto sm:ml-0">
                        <FloatingActionButton onAction={onFabAction} />
                    </div>
                ) : null}
            </div>
        </div>
    )
}
