export default function TablePagination({ currentPage, totalPages, onPageChange, totalItems, itemsPerPage }) {
    const startItem = totalItems === 0 ? 0 : (currentPage - 1) * itemsPerPage + 1
    const endItem = Math.min(currentPage * itemsPerPage, totalItems)

    const getPageNumbers = () => {
        const pages = []
        if (totalPages <= 7) {
            for (let i = 1; i <= totalPages; i++) pages.push(i)
        } else {
            pages.push(1)
            if (currentPage > 3) pages.push('...')
            for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
                pages.push(i)
            }
            if (currentPage < totalPages - 2) pages.push('...')
            pages.push(totalPages)
        }
        return pages
    }

    const pageNumbers = getPageNumbers()

    return (
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-4">
            <p className="text-sm text-foreground-500">
                Showing{' '}
                <span className="font-semibold text-foreground-700">
                    {startItem}-{endItem}
                </span>{' '}
                of <span className="font-semibold text-foreground-700">{totalItems}</span> requests
            </p>

            <div className="flex items-center gap-1">
                <button
                    type="button"
                    onClick={() => onPageChange(currentPage - 1)}
                    disabled={currentPage === 1}
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-foreground-500 border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer"
                >
                    <i className="ri-arrow-left-s-line" />
                </button>

                {pageNumbers.map((page, idx) =>
                    page === '...' ? (
                        <span key={`dots-${idx}`} className="w-9 h-9 flex items-center justify-center text-foreground-400 text-sm">
                            ...
                        </span>
                    ) : (
                        <button
                            key={page}
                            type="button"
                            onClick={() => onPageChange(page)}
                            className={`w-9 h-9 rounded-lg text-sm font-semibold transition-all cursor-pointer ${
                                page === currentPage
                                    ? 'bg-primary-600 text-white shadow-sm border border-primary-600'
                                    : 'text-foreground-600 border border-slate-200 bg-white hover:bg-slate-50'
                            }`}
                        >
                            {page}
                        </button>
                    )
                )}

                <button
                    type="button"
                    onClick={() => onPageChange(currentPage + 1)}
                    disabled={currentPage === totalPages}
                    className="w-9 h-9 rounded-lg flex items-center justify-center text-foreground-500 border border-slate-200 bg-white hover:bg-slate-50 disabled:opacity-30 disabled:cursor-not-allowed transition-all cursor-pointer"
                >
                    <i className="ri-arrow-right-s-line" />
                </button>
            </div>
        </div>
    )
}
