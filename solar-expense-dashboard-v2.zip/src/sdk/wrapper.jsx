import KFSDK from '@kissflow/lowcode-client-sdk'
import React, { useState, useEffect } from 'react'
import { KissflowSDKContext } from './context.jsx'

let kf

export function SDKWrapper(props) {
    const [kfInstance, setKfInstance] = useState(null)
    const [sdkFailed, setSdkFailed] = useState(false)

    useEffect(function onLoad() {
        if (typeof window !== 'undefined' && window.kf) {
            kf = window.kf
            setKfInstance(window.kf)
            setSdkFailed(false)
            return
        }

        KFSDK.initialize()
            .then((sdk) => {
                window.kf = kf = sdk
                setKfInstance(sdk)
                setSdkFailed(false)
                console.info('[solar-expense-dashboard] SDK initialized')
            })
            .catch((err) => {
                setSdkFailed(true)
                console.warn('[solar-expense-dashboard] SDK unavailable:', err?.message || err)
            })
    }, [])

    const sdkValue = { kf: kfInstance, sdkReady: !!kfInstance && !kfInstance?.isError }

    return (
        <KissflowSDKContext.Provider value={sdkValue}>
            {sdkFailed && (
                <div
                    style={{
                        padding: '8px 16px',
                        background: '#fef3c7',
                        color: '#92400e',
                        fontSize: 12,
                        textAlign: 'center',
                    }}
                >
                    Preview mode — open inside Kissflow for live data.
                </div>
            )}
            {props.children}
        </KissflowSDKContext.Provider>
    )
}

export { kf }
